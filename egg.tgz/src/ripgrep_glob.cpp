// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Glob-filtered grep\n", stdout);
  return lionss_run_workload("ripgrep_glob");
}
