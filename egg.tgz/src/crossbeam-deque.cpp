// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Benchmark steal throughput"); }
int main(){
  announce();
  return lionss_run_workload("crossbeam-deque");
}
