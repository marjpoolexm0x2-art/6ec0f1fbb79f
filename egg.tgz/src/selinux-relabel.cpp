// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Relabel filesystem"); }
int main(){
  announce();
  return lionss_run_workload("selinux-relabel");
}
